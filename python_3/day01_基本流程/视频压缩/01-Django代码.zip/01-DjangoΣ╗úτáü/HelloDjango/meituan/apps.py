from django.apps import AppConfig


class MeituanConfig(AppConfig):
    name = 'meituan'
